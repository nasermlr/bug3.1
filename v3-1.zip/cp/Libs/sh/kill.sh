#!/bin/bash
#By Alireza