<?php
//ini_set('display_errors', '1');
//ini_set('display_startup_errors', '1');
//error_reporting(E_ALL);
	require("Libs/Controller.php");
	require("Libs/View.php");

	require("Libs/Model.php");
	require("Libs/Database.php");
	require("Config/database.php");
	require("Config/define.php");

	require("Libs/Session.php");
	require("Libs/Bootstrap.php");

	$app = new Bootstrap();
?>
